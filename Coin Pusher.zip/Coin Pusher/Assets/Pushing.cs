﻿using UnityEngine;
using System.Collections;

public class Pushing : MonoBehaviour {


	public Vector3 pointB;
	
	IEnumerator Start()
	{
		var pointA = transform.position;
		while(true)
		{
			yield return StartCoroutine(MoveObject(transform, pointA, pointB, 3.0f));
			yield return StartCoroutine(MoveObject(transform, pointB, pointA, 3.0f));
		}
	}
	
	IEnumerator MoveObject(Transform thisTransform, Vector3 startPos, Vector3 endPos, float time)
	{
		var i = 0.0f;
		var rate = 1.0f/time;
		while(i < 1.0f)
		{
			i += Time.deltaTime * rate;
			thisTransform.position = Vector3.Lerp(startPos, endPos, i);
			yield return null;
		}
	}
	//private Vector3 newPosition;

	// Use this for initialization
	//void Awake () 
	//{
		//newPosition = transform.position;
	//}
	
	// Update is called once per frame
	//void FixedUpdate () 
	//{

		//TrayPushing();
	//	transform.position = new Vector3(transform.position.x, transform.position.y, Mathf.PingPong(Time.time, -4));
	
	//}

	/* void TrayPushing()
	{
		bool pushing = true;

		Vector3 posFront = new Vector3(0, -8.5f, -2.5f);
		Vector3 posBack = new Vector3(0, -8.5f, 1.6f);

		if (transform.position == posFront)
		{
			Debug.Log("At Front");
		}
		else if (transform.position == posBack)
		{
			Debug.Log("At Back");
		}

		if (Input.GetKeyDown(KeyCode.B))
			newPosition = posFront;
		if (Input.GetKeyDown(KeyCode.N))
			newPosition = posBack;

		transform.position = Vector3.Lerp(transform.position, newPosition, Time.deltaTime * 5);
	}
	*/
}